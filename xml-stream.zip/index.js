module.exports = require('./lib/xml-stream.js');
